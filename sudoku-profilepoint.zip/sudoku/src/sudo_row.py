from sudo_unit import SudoUnit

class Row(SudoUnit):
    def __init__(self, cells):
        super().__init__(cells)
    