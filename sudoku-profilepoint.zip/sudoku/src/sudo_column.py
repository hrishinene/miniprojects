from sudo_unit import SudoUnit

class Column(SudoUnit):
    def __init__(self, cells):
        super().__init__(cells)