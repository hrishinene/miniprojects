from sudo_unit import SudoUnit

class MiniMatrix(SudoUnit):
    def __init__(self, cells):
        super().__init__(cells)